import express from "express";
import mongoose from "mongoose";

import path from "path";
import { fileURLToPath } from "url";

import bodyParser from "body-parser";

const app = express();

// connecting to mongoDb
//,{useNewUrlParser:true, useUnifiedToplogy:true} -> optional
mongoose
    .connect("mongodb://localhost:27017/EcoomerceProduct")
    .then(() => {
        console.log("Server is connected");
    })
    .catch((error) => {
        console.log(error);
    });

// Define file and path directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// define {body-parser} middlware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

// making schemas
const productSchemas = mongoose.Schema({
    name: String,
    description: String,
    catgories: String,
    price: Number,
});

// making collection
const productCollection = new mongoose.model("product", productSchemas);

// creating product Api
app.post("/api/v1/product/new", async (req, res) => {
    const product = await productCollection.create(req.body);

    // sending response
    res.status(200).json({
        success: true,
        product,
    });
});

// read product;
app.get("/api/v1/product", async (req, res) => {
    const product = await productCollection.find();
    // sending response
    res.status(200).json({
        success: true,
        product,
    });
});

// update product
app.put("/api/v1/product/:id", async (req, res) => {
    let product = await productCollection.findById(req.params.id);

    if (!product) {
        return res.status(500).json({
            success: false,
            message: "there is no such product"
        });
    }

    // {new:true, useFindAndModify:true, runValidator:true}
    product = await productCollection.findByIdAndUpdate(req.params.id, req.body);

    // sending res
    res.status(200).json({
        success: true,
        product
    });
});

// delete product
app.delete("/api/v1/product/:id", async (req, res) => {
    let product = await productCollection.findById(req.params.id);

    if (!product) {
        return res.status(500).json({
            success: false,
            message: "there is no such product"
        });
    }

    // {new:true, useFindAndModify:true, runValidator:true}
    product = await productCollection.findByIdAndDelete(req.params.id, req.body);

    // This is also a way to delete product ->
    // await product.remove(); 

    // sending response
    res.status(200).json({
        success: true, 
        message: "Product is deleted",
        product
    });
});

// creating server
const PORT = 8000;
const server = "localhost";

app.listen(PORT, server, () => {
    console.log(`server is runnig on http://${server}:${PORT}`);
});
